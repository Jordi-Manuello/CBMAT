%This script creates sub-samples of experiments to test subsampling reliability
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%foci=a txt file with x,y,z coordinates for each focus of effect.
%     No header must be present in the first line of the txt.
%ns=number of sub-samples to be created
%rep=allowing replacement or not in sub-sampling 
%     If 1 an experiment can be included in more than one sub-sample
%     If 0 each experiment will be included in only one sub-sample
%nexp=number of experiments in each sub-sample. 
%When rep is set to 0, nexp is automatically adjusted to create ns sub-samples of equal size. 
%In this case, if nexp is not a divisor of the total number of experiments in the
%dataset, an extra sub-sample is created containing the remaining experiments.

%The output 'sub_sample_i.txt' is a txt file listing the experimens included in each
%sub-sample
%The value of 'p' is the number of sub-samples created

%Examples:
%p=create_subsets('test.txt',2,5,0)
%     creates 2 sub-samples with 5 experiments each. Each experiment appears in one
%     sub-sample only. This can be used to prepare a split-half analysis. 
%     of the original dataset of 10 experiments listed in test.txt 
%p=create_subsets('test.txt',4,5,1)
%     creates 4 sub-samples with 5 experiments each. The same experiment
%     can appear in more than one sub-sample. This can be used to prepare a
%     bootstrap analysis.

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p=create_subsets(foci,ns,nexp,rep)

Z=load_foci(foci); 

if nexp>size(Z,1)
    disp('Error: The number of experiments in each sub-sample can not be higher than the total number of experiments in the dataset')
    return
end

if rep==0
    p=randperm(size(Z,1));
    check=size(Z,1)/ns;
    nexp=fix(check); %This is to adjust if nexp is not a divisor of the n of
                     %experiments in the dataset
    ext=p(nexp*ns+1:end);
    sub=(reshape(p(1:nexp*ns),[nexp,ns]))';
elseif rep==1
    for i=1:ns
        sub(i,1:nexp)=randperm(size(Z,1),nexp);
    end
    ext=[];
end

%Now save the reduced set

    %Extract number of subjects
exp=Z(:,1);
s='// Subjects=';
spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    subj(i)=cellstr(spl{i,1}{1,2});
end
subj=str2double(subj');
    
    
    %Extract experiment name
    spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    det(i,1)=cellstr(spl{i,1}{1,1});
end
exp_take=cell2table(det);

%Now build the series of txt
for i=1:size(sub,1)
    name=strcat('sub_sample_',num2str(i),'.txt');
    out = fopen(name,'w');
    %space=strcat('// Reference=Talairach'); %Change here for MNI
    %fprintf(out,'%s \n',space); %this is to print the standard space as first line
    for k=1:size(sub,2)
        line_1=char(strcat(exp_take.det(sub(i,k)))); %To keep the original exp name
        line_2=strcat('// Subjects=',num2str(subj(sub(i,k))));
        fprintf(out,'%s \n',line_1);
        fprintf(out,'%s \n',line_2);
        foci=Z{sub(i,k),2};
        foci=reshape(foci',[],1);
        fprintf(out,'%4.2f %4.2f %4.2f \n',foci);
        fprintf(out,'\n',foci);
    end
end
if isempty(ext)==0 & rep==0 %This creates the list of extra experiments
   name=strcat('sub_sample_extra.txt');
   out = fopen(name,'w');
   %space=strcat('// Reference=Talairach'); %Change here for MNI
   %fprintf(out,'%s \n',space); %this is to print the standard space as first line
        for j=1:size(ext,2)
        line_1=char(strcat(exp_take.det(ext(j)))); %To keep the original exp name
        line_2=strcat('// Subjects=',num2str(subj(ext(j))));
        fprintf(out,'%s \n',line_1);
        fprintf(out,'%s \n',line_2);
        foci=Z{ext(j),2};
        foci=reshape(foci',[],1);
        fprintf(out,'%4.2f %4.2f %4.2f \n',foci);
        fprintf(out,'\n',foci);
        end
 end

p=ns;
disp('Done! Thank you for using CBMAT! :-D')
return