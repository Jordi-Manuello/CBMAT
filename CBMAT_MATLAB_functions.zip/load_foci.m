%This script reads the dataset and prepares data for manipulation in
%Matlab. It is called by the other functions of the toolbox, therefore it
%should be modified with caution to avoid malfunctioning.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%foci=a txt file with x,y,z coordinates for each focus of effect.
%     No header must be present in the first line of the txt.

%Example: Z=load_foci('test_foci.txt');

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Z=load_foci(foci)
    fid=fopen(foci);
    k=1;
    %read one line of the txt
    tline = fgetl(fid);
    while isnumeric(tline)==0
        if numel(tline)==0 & ischar(tline)==1
            %this is an empty line between experiments
            %tline='*';
            k=k+1;
            tline = fgetl(fid);
        end
        if tline(1)=='/'
            %take the lines starting with / and thus containing meta-data
            meta=[];
            meta=num2cell(meta);
            i=1;
            while tline(1)=='/'
                meta{i}=tline;
                tline = fgetl(fid);
                i=i+1;
            end
            out{k,1}=strjoin(meta);
        elseif tline(1)~='/' & numel(tline)>0 & isnumeric(tline)==0
            %take the lines containing foci
            r=1;
            foci=[];
            while numel(tline)>0 & isnumeric(tline)==0
                foci(r,:)=str2num(tline);
                r=r+1;
                tline = fgetl(fid);
                out{k,2}=foci;
            end
            %out{k,2}=foci;
%         elseif numel(tline)==0 & ischar(tline)==1
%             %this is an empty line between experiments
%             k=k+1;
%             tline = fgetl(fid);
        end
    end
                  
Z=out;

%Now check potential duplicates and remove them
k=1;
rem=[];
for i=1:size(Z,1)
    x1=Z{i,1};
    for j=1:size(Z,1)
        x2=Z{j,1};
        if i~=j & j>i
            if regexp(x1,x2)==1 
                comp=unique(ismember(Z{i,2},Z{j,2}));
                if comp(1)==1
                    rem(k)=j;
                    k=k+1;
                end
            end
        end
    end
end

rem=unique(rem);  

Z(rem,:)=[];
            

disp('Foci loaded correctly.')
return