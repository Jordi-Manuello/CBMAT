%This script is the walk-through of the complete run described in the CBMAT
%paper
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%All the variables and arguments are described in the specific functions.
%Please note that the tool 'Tools for NIfTI and ANALYZE image' 
%(https://www.mathworks.com/matlabcentral/fileexchange/8797-tools-for-nifti-and-analyze-image) must be in the path. 

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

%1) Use dataset_hist to inspect the original dataset.
[m_subj,m_year]=dataset_hist('test_foci.txt',15);
%%%%%%%

clear all
close all

%2) Use remove_multiple to exclude multiple experiments from a same paper.
rng(1); %This is to ensure exact reproducibility of this example complete run.
p=remove_multiple('test_foci.txt',2);
%%%%%%%

clear all
close all

%3) Use filter_by_tissue to only retain foci located in the GM.
p=filter_by_tissue('foci_cleaned_rand.txt','GM_mask.nii');
%%%%%%%

clear all
close all

%4) Use prepare_MACM to select experiments with at least one focus in a user defined ROI.
p=prepare_MACM('foci_tissue.txt','ROI.nii');
%%%%%%%

clear all
close all

%5) Use create_LOEO to prepare data for a standard Leave One Experiment Out analysis.
p=create_LOEO('foci_cleaned_rand.txt',0);
%%%%%%%

clear all
close all

%6) Use create_subsets to prepare data for a split-half analysis.
p=create_subsets('foci_cleaned_rand.txt',2,15,0);

%generate the histograms of the sub-samples
%(Please note that this step will overwright the images generated in line
%15)
[m_subj,m_year]=dataset_hist('sub_sample_1.txt',20);
[m_subj,m_year]=dataset_hist('sub_sample_2.txt',20);