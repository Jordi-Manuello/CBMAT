%This script allows to select foci in gray matter or white matter only.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%foci=a txt file with x,y,z Talairach coordinates for each focus of effect.
%     No header must be present in the first line of the txt.
%ROI=a nii file containing a binary mask for GM or WM

%The output 'foci_tissue' is a txt file listing only foci in the desired tisssue for each experiment
%The value of 'p' is the number of experiments retained

%Please note the the functions 'load_nii' and 'save_nii' from 'Tools for NIfTI and ANALYZE image' 
%(https://www.mathworks.com/matlabcentral/fileexchange/8797-tools-for-nifti-and-analyze-image) must be in the path. 

%Example: p=filter_by_tissue('test_foci.txt','GM_mask.nii')

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p=filter_by_tissue(foci,ROI)


%Call do_parse to read the foci file
Z=load_foci(foci);

%Load the ROI (this must be in the same space of the foci coordinates)
nii=load_nii(ROI);
img=nii.img;

%For each experiment keep foci in the desired tissue only.
for i=1:size(Z,1)
    xyz=Z{i,2};
    %Convert Tal coordinates to matrix coordinates
    origin=[41 59 32]; %This are the matrix coordinates of the origin of the Talairach
    mat_coord=zeros(size(xyz,1),size(xyz,2));
    
    for j=1:size(xyz,1)
        mat_coord(j,1)=xyz(j,1)/2+origin(1);
        mat_coord(j,2)=xyz(j,2)/2+origin(2);
        mat_coord(j,3)=xyz(j,3)/2+origin(3);
    end
    mat_coord=round(mat_coord);
    
    check=zeros(size(mat_coord,1),1);
    for j=1:size(mat_coord,1)
        if mat_coord(j,1)>size(img,1) | mat_coord(j,2)>size(img,2) | mat_coord(j,3)>size(img,3)
           check(j,1)=0; %These are foci outside the ROI matrix
        else check(j,1)=img(mat_coord(j,1),mat_coord(j,2),mat_coord(j,3));
        end
    end
    
    %Remove foci located outside the desired tissue
    Z{i,2}(find(check==0),:)=[];
    
    %Remove experiments without foci
    if size(Z{i,2},1)>0
        take(i,1)=1; %This marks an experiment to be retained
    elseif size(Z{i,2},1)==0
        take(i,1)=0; %This marks an experiment to be excluded
    end
end

%Create the reduced set

    input=Z(find(take),:);
    
%Extract subjects details
exp=input(:,1);
s='// Subjects=';
spl = regexp(exp,s,'split');
for i=1:size(input,1)
    subj(i)=cellstr(spl{i,1}{1,2});
end
subj=str2double(subj)';

%Extract experiment name
for i=1:size(input,1)
    det(i,1)=cellstr(spl{i,1}{1,1});
end
    
%Now build the txt
    exp_take=cell2table(det);
    name=('foci_tissue.txt'); %This sets the output name
    out = fopen(name,'w');
    %space=strcat('// Reference=Talairach'); %Change here for MNI
    %fprintf(out,'%s \n',space); %this is to print the standard space as first line
    k=1;
    for k=1:size(input,1)
        %line_1=strcat('// Exp_',num2str(k)); %This option renames as Exp_i ...
        line_1=char(strcat(exp_take.det(k))); %To keep the original exp name
        line_2=strcat('// Subjects=',num2str(subj(k)));
        fprintf(out,'%s \n',line_1);
        fprintf(out,'%s \n',line_2);
        foci=input{k,2};
        foci=reshape(foci',[],1);
        fprintf(out,'%4.2f %4.2f %4.2f \n',foci);
        fprintf(out,'\n',foci);
    end

p=size(input,1);
disp('Done! Thank you for using CBMAT! :-D')
return


