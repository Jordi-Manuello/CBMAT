%This script creates histograms showing features of the data set
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%foci=a txt file with x,y,z Talairach coordinates for each focus of effect.
%
%sbins=the number of bins to be visualized in the user-defined histogram of sample size.
%      Vary this to find the optimal balance between the top and the bottom
%      histograms.

%The output 'sample_size.jpg' shows the distribution of sample sizes.
%The output 'year_of_publication.jpg' shows the distribution of year of
%publication.
%The value of 'm_subj' is the average sample size of the experiments in the
%dataset. It is also marked with the red line on the related histogram.
%The value of 'm_year' is the median of the publication year of the experiments in the
%dataset. It is also marked with the red line on the related histogram.

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [m_subj,m_year]=dataset_hist(foci,sbins)

Z=load_foci(foci);

%Extract number of subjects
exp=Z(:,1);
s='Subjects=';
spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    subj(i)=cellstr(spl{i,1}{1,2});
end
subj=str2double(subj');

m_subj=mean(subj);

f1=figure;
subplot(3,1,1);
histogram(subj);
hold on
line([m_subj, m_subj], ylim, 'LineWidth', 2, 'Color', 'r');
hold off
title(strcat('Sample size distribution (mean=',num2str(m_subj),' n=',num2str(size(exp,1)),')'));

subplot(3,1,2)
histogram(subj,sbins);
hold on
line([m_subj, m_subj], ylim, 'LineWidth', 2, 'Color', 'r');
hold off

subplot(3,1,3)
edges=[min(subj):1:max(subj)];
histogram(subj,'BinEdges',edges);
hold on
line([m_subj, m_subj], ylim, 'LineWidth', 2, 'Color', 'r');
hold off

f1.Position=[500 500 500 600];

saveas(f1,'sample_size.jpg');

%Now extract First author
exp=Z(:,1);
s=',';
spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    FA(i)=cellstr(spl{i,1}{1,1});
end
FA=FA'; %This is not used, but needed for the script to work

%and year
for i=1:size(Z,1)
    y1(i)=cellstr(spl{i,1}{1,2});
end
s=':';
y2 = regexp(y1,s,'split');

for i=1:size(Z,1)
    year(i)=cellstr(y2{1,i}{1,1});
end
year=str2double(year');

m_year=median(year);

f2=figure
histogram(year);
hold on
title(strcat('Year of publication distribution (median=', num2str(m_year),' n=',num2str(size(exp,1)),')'));
line([m_year, m_year], ylim, 'LineWidth', 2, 'Color', 'r');
saveas(f2,'year_of_publication.jpg');
hold off;

disp('Done! Thank you for using CBMAT! :-D')
return