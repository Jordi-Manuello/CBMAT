%This script removes multiple experiments coming from a same paper.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%foci=a txt file with x,y,z coordinates for each focus of effect.
%     No header must be present in the first line of the txt.
%mode=the criterion used to remove experiments. 
%     If 1 the experiment with  greater sample size will be retained
%     If 2 one experiment will be randomly retained
%seed=the value used to initialize the random number generator process.
%     Specify the same value of seed across multiple repetition of the procedure 
%     to ensure the exact replication of the sampling process. 
%     When seed is not specified, the default option is used, as explained 
%     in the MATLAB guide of the rng function. 

%The output 'foci_cleaned' is a txt file listing one experiment per study
%only
%The value of 'p' is the number of experiments retained

%Example: p=remove_multiple('test_foci.txt',2);

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p=remove_multiple(foci,mode,seed)

Z=load_foci(foci); 

%Set the random generator, if the argument seed is specified
if nargin ==3
    rng(seed)
end

%Now split the txt to extract First author
exp=Z(:,1);
s=',';
spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    FA(i)=cellstr(spl{i,1}{1,1});
end
FA=FA';

%year
for i=1:size(Z,1)
    y1(i)=cellstr(spl{i,1}{1,2});
end

s=':';
y2 = regexp(y1,s,'split');

for i=1:size(Z,1)
    year(i)=cellstr(y2{1,i}{1,1});
end
year=year';

%now merge first author and year
FA_y=strcat(FA,year);
%This adds an extra row to avoid index errors
FA_y{size(FA_y,1)+1,1}='get_out';

%and subjects
%s='Subjects=';
s='// Subjects=';
spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    subj(i)=cellstr(spl{i,1}{1,2});
end
subj=subj';

%Look for experiments coming from same paper
%comp=1;
k=1;
i=1;
while i<(size(FA_y,1))
    n=0;
    comp=1;
    j=i+1;
    while comp==1
        comp=strcmp(FA_y(i,1),FA_y(j,1));
        if comp==1
            j=j+1;
            n=n+1;
        else n=n;
             j=j;
        end
    end
    if n>0
        if mode==1
            %%%take that with greater sample size between i and j
            cs=str2double(subj(i:j-1,1));
            nmax = find(cs== max(cs(:)));
            if length(nmax)>1 %Case in which more experiments have same sample size
                M=nmax(randi([1,length(nmax)],1,1));
            else [I M]=max(cs);
            end
            take(k)=i+M-1;
            i=j;
        elseif mode==2
            take(k)=randi([i,j-1],1,1);
            i=j;
        end
    else take(k)=i;
        i=i+1;
    end
       k=k+1;
end
    
%Now save the reduced set

    input=Z(take,:);
    subj_red=str2double(subj);
    subj_red=subj_red(take,:);
    
    %Extract experiment name
    exp=input(:,1);
    spl = regexp(exp,s,'split');
for i=1:size(input,1)
    det(i,1)=cellstr(spl{i,1}{1,1});
end
exp_take=cell2table(det);
    
if mode==1
    name=('foci_cleaned_max_sample.txt'); %This sets the uotput name
elseif mode==2
    name=('foci_cleaned_rand.txt'); %This sets the uotput name
end
    out = fopen(name,'w');
    %space=strcat('// Reference=Talairach'); %Change here for MNI
    %fprintf(out,'%s \n',space); %this is to print the standard space as first line
    k=1;
    for k=1:size(input,1)
        %line_1=strcat('// Exp_',num2str(k)); %This renames as Exp_i ...
        line_1=char(strcat(exp_take.det(k)));
        line_2=strcat('// Subjects=',num2str(subj_red(k)));
        fprintf(out,'%s \n',line_1);
        fprintf(out,'%s \n',line_2);
        foci=input{k,2};
        foci=reshape(foci',[],1);
        fprintf(out,'%4.2f %4.2f %4.2f \n',foci);
        fprintf(out,'\n',foci);
    end
    
    p=size(input,1);
    disp('Done! Thank you for using CBMAT! :-D')
    return
