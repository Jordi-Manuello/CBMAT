%This script creates sub-samples of experiments to perform "Leave One
%Experiment Out" analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%foci=a txt file with x,y,z coordinates for each focus of effect.
%     No header must be present in the first line of the txt.
%add=increment experiments to be removed
%     If 0 the "Leave One Experiment Out" analysis is prepared, exluding
%     one experiment at each iteration.
%     If 1 the "Leave n+1 Experiment Out" analysis is prepared, exluding
%     one more experiment at each iteration.

%The output 'LOEO_i.txt' is a txt file listing the experiments retained at
%each iteration
%The value of 'p' is the number of sub-samples created

%Example: p=create_LOEO('test_foci.txt',1);

%Coded by Jordi Manuello (FocusLab, University of Torino) in June 2023.
%
%Copyright 2023 Jordi Manuello. 
%
%Licensed under the Apache License, Version 2.0 (the "License");
%    you may not use this file except in compliance with the License.
%    You may obtain a copy of the License at
% 
%        http://www.apache.org/licenses/LICENSE-2.0
% 
%    Unless required by applicable law or agreed to in writing, software
%    distributed under the License is distributed on an "AS IS" BASIS,
%    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%    See the License for the specific language governing permissions and
%    limitations under the License.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function p=create_LOEO(foci,add)

Z=load_foci(foci); 

%Extract number of subjects
exp=Z(:,1);
s='// Subjects=';
spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    subj(i)=cellstr(spl{i,1}{1,2});
end
subj=str2double(subj');
    
    
    %Extract experiment name
    spl = regexp(exp,s,'split');
for i=1:size(Z,1)
    det(i,1)=cellstr(spl{i,1}{1,1});
end
exp_take=cell2table(det);

%Now build the series of txt
for i=1:size(Z,1)
    name=strcat('LOEO_',num2str(i),'.txt');
    out = fopen(name,'w');
    %space=strcat('// Reference=Talairach'); %Change here for MNI
    %fprintf(out,'%s \n',space); %this is to print the standard space as first line
    if add==0
        for k=1:size(Z,1)
            if k==i
                k=k;
            else
                line_1=char(strcat(exp_take.det(k))); %To keep the original exp name
                line_2=strcat('// Subjects=',num2str(subj(k)));
                fprintf(out,'%s \n',line_1);
                fprintf(out,'%s \n',line_2);
                foci=Z{k,2};
                foci=reshape(foci',[],1);
                fprintf(out,'%4.2f %4.2f %4.2f \n',foci);
                fprintf(out,'\n',foci);
            end
        end
    elseif add==1
        for k=1:(size(Z,1)-i)
            line_1=char(strcat(exp_take.det(k))); %To keep the original exp name
            line_2=strcat('// Subjects=',num2str(subj(k)));
            fprintf(out,'%s \n',line_1);
            fprintf(out,'%s \n',line_2);
            foci=Z{k,2};
            foci=reshape(foci',[],1);
            fprintf(out,'%4.2f %4.2f %4.2f \n',foci);
            fprintf(out,'\n',foci);
        end
    end
end

p=i;
disp('Done! Thank you for using CBMAT! :-D')
return